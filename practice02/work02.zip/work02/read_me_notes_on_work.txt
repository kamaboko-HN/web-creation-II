課題２ シンプルなページ(simple page)のSCSSの作成


課題２は、SASSの記述のトレーニング（tranning）です。

２日目の教材の、work02を確認してください。
「site_data_solarize」というフォルダに、完成したページがあります。

完成した「style.css」と同じものができるように、scssフォルダにある、style.scssをscssの表記に変更してください。
style.scss→表記はcssの通常表記になっているので、scssの表記にしてください。


（1）SCSSでネストを使って、グループ化してみよう
（2）色コードで同じものは変数でまとめてみよう
（3）同じ記述については、extendかmixinを使って記述を省略してみよう
（4）ファイルを分割して編集しやすくしよう！
　　→　Variable,Button,Wrapper,Header,Dropotron,Banner,Main,Footer　のそれぞれファイルを作り、importしよう

チェックの観点は、元のソースのデザインが崩れていないか？
上記4つのうちどれだけ設定できているか？

完成したら、work02フォルダをzip圧縮して、Classroomから提出してください